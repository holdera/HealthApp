<?php

namespace health\userBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class healthuserBundle extends Bundle
{
}
