<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="health, fitness, exercise, lifestyle, healthy, weightloss">
    <meta name="description" content="spreading awareness of living a healthy lifestyle,
	 lose weight, build muscle, its not a diet, its a lifestyle change">
    <meta name="viewport" content="width=device-width, user-scalable=no">
    <title>The Healthy LifeStyle</title>

    <link rel="stylesheet" href="Resources/public/css/styles.css" >
    <link rel="stylesheet" href="Resources/public/css/bootstrap.min.css">

</head>

<?php
/**
 * Created by PhpStorm.
 * User: alannahholder
 * Date: 2014-05-15
 * Time: 4:12 PM
 */