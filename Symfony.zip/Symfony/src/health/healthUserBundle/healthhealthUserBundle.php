<?php

namespace health\healthUserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class healthhealthUserBundle extends Bundle
{
}
