<?php

namespace health\LifestyleBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class healthLifestyleBundle extends Bundle
{
}
