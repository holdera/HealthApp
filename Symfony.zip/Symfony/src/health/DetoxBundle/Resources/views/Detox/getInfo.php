<?php

$answer1 = $_POST['answer1'];
$answer2 = $_POST['answer2'];
$answer3 = $_POST['answer3'];
$answer4 = $_POST['answer4'];

if($answer2){
    echo "haha";
}
/**
 * Created by PhpStorm.
 * User: alannahholder
 * Date: 2014-06-08
 * Time: 9:13 PM
 */ 