<?php

namespace health\DetoxBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class healthDetoxBundle extends Bundle
{
}
