<?php

namespace health\forumBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class healthforumBundle extends Bundle
{
}
