<?php

namespace health\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class healthAdminBundle extends Bundle
{
}
