<?php

namespace health\ResourcesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class healthResourcesBundle extends Bundle
{
}
