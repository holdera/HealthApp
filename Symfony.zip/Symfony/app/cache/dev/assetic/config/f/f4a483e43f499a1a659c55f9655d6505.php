<?php

// healthuserBundle:Default:index.html.twig
return array (
);
