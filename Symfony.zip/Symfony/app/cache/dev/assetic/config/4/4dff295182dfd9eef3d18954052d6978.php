<?php

// healthLifestyleBundle:Default:index.html.twig
return array (
);
