<?php

// healthResourcesBundle:Default:index.html.twig
return array (
);
