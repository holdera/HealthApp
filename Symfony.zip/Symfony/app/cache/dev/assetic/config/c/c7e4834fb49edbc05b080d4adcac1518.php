<?php

// healthLifestyleBundle:Cheat:cheatGenerator.html.twig
return array (
);
