<?php

// healthuserBundle:Recover:security.html.twig
return array (
  '2cd4855' => 
  array (
    0 => 
    array (
      0 => '@healthuserBundle/Resources/public/css/*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/2cd4855.css',
      'name' => '2cd4855',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
