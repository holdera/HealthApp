<?php

// healthLifestyleBundle:healthSample:sample.html.twig
return array (
  '8b11947' => 
  array (
    0 => 
    array (
      0 => '@healthLifestyleBundle/Resources/public/css/*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/8b11947.css',
      'name' => '8b11947',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
