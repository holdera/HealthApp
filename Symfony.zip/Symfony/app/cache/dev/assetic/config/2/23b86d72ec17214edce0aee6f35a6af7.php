<?php

// healthResourcesBundle:Gym:finder.html.twig
return array (
  '4f9dc43' => 
  array (
    0 => 
    array (
      0 => '@healthhealthUserBundle/Resources/public/css/*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/4f9dc43.css',
      'name' => '4f9dc43',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
